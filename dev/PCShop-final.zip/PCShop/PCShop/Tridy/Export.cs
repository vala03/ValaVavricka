﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using iTextSharp.text;
using iTextSharp.text.pdf;


namespace PCShop
{
    class Export
    {
        public void ExportDoPDF(int cisloF, string nazevZbozi, double cenaBezDPH, int sazbaDPH, 
            int pocetKusu, DateTime datumObjednani, string vyridil, string jmenoKupce, 
            string prijmeniKupce, string adresaKupce, string telefonKupce, string emailKupce)
        {
            string jmeno = DateTime.Now.ToString("yyyyMMdd_HHmmss");
            Document doc = new Document(iTextSharp.text.PageSize.A4);
            PdfWriter wri = PdfWriter.GetInstance(doc, new FileStream(jmeno+".pdf", FileMode.Create));

            string myFont = @"C:\windows\fonts\verdana.ttf";
            iTextSharp.text.pdf.BaseFont bfR = iTextSharp.text.pdf.BaseFont.CreateFont(myFont, iTextSharp.text.pdf.BaseFont.IDENTITY_H, iTextSharp.text.pdf.BaseFont.EMBEDDED);

            iTextSharp.text.BaseColor clrBlack = new iTextSharp.text.BaseColor(0, 0, 0);
            iTextSharp.text.Font fntHead = new iTextSharp.text.Font(bfR, 12, iTextSharp.text.Font.NORMAL, clrBlack);
            iTextSharp.text.Font nadpis = new iTextSharp.text.Font(bfR, 24, iTextSharp.text.Font.BOLD, clrBlack);
            iTextSharp.text.Font tucny = new iTextSharp.text.Font(bfR, 12, iTextSharp.text.Font.BOLD, clrBlack);

            doc.Open();

            PdfPTable cislo = new PdfPTable(1);
            
            var text = new Paragraph( "FAV č. " + cisloF, nadpis);
            PdfPCell cell = new PdfPCell(text);
            cell.BorderColor = BaseColor.WHITE;
            cislo.AddCell(cell);
            doc.Add(cislo);
            doc.Add(new Paragraph(" "));

            PdfPTable spol = new PdfPTable(2);
            text = new Paragraph(jmenoKupce + " " + prijmeniKupce + "\n" + adresaKupce + "\nTel. " + telefonKupce + "\n" + emailKupce, fntHead);
            spol.AddCell(text);
            text = new Paragraph("Vala-Vavřička, s. r. o.\nTolstého 16\n586 01 Jihlava", fntHead);
            spol.AddCell(text);
            doc.Add(spol);
            doc.Add(new Paragraph(" "));

            PdfPTable penize = new PdfPTable(2);
            text = new Paragraph("Způsob úhrady: Hotově\nPeněžní ústav: --\nČíslo účtu: --\n\nVariabilní symbol: --\nKonstatní symbol: --\nSpecifický symbol: --", fntHead);
            penize.AddCell(text);
            DateTime datumSplatnosti = datumObjednani.AddDays(14);
            text = new Paragraph("Datum vystavení: " + datumObjednani.ToShortDateString() + "\n\nDatum splatnosti: "  + datumSplatnosti.ToShortDateString(), fntHead);
            penize.AddCell(text);
            doc.Add(penize);
            doc.Add(new Paragraph(" "));

            PdfPTable zbozi = new PdfPTable(5);

            text = new Paragraph("Název položky", fntHead);
            zbozi.AddCell(text);
            text = new Paragraph("Množství", fntHead);
            zbozi.AddCell(text);
            text = new Paragraph("Cena položky bez DPH", fntHead);
            zbozi.AddCell(text);
            zbozi.AddCell("DPH %");
            text = new Paragraph("Cena celkem s DPH", fntHead);
            zbozi.AddCell(text);
            doc.Add(zbozi);

            PdfPTable zbozi2 = new PdfPTable(5);

            text = new Paragraph(nazevZbozi, fntHead);
            zbozi2.AddCell(text);
            text = new Paragraph(pocetKusu + " ks", fntHead);
            zbozi2.AddCell(text);
            text = new Paragraph(cenaBezDPH + " Kč", fntHead);
            zbozi2.AddCell(text);
            zbozi2.AddCell(sazbaDPH + " %");
            double celkem = cenaBezDPH +  (cenaBezDPH * (Convert.ToDouble(sazbaDPH) / 100.00));
            text = new Paragraph(celkem + " Kč", fntHead);
            zbozi2.AddCell(text);


            doc.Add(zbozi2);
            doc.Add(new Paragraph(" "));

            PdfPTable paticka = new PdfPTable(2);
            text = new Paragraph("Poznámka: \nVyřídil:" + vyridil + "\nDěkujeme za spolupráci.", fntHead);
            paticka.AddCell(text);
            text = new Paragraph("Suma bez DPH: " + (cenaBezDPH) + " Kč\nDPH: " + sazbaDPH + " %\nCelkem s DPH: " + (celkem) + " Kč", tucny);
            paticka.AddCell(text);
            doc.Add(paticka);

            doc.Close();
        }
    }
}
