﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PCShop
{
    public class Zakaznici
    {
        public int id { get; }
        public string jmeno { get; }
        public string prijmeni { get; }
        public string adresa { get; }
        public string telefon { get; }
        public string email { get; }

        public Zakaznici(int id, string jmeno, string prijmeni, string adresa,
            string telefon, string email)
        {
            this.id = id;
            this.jmeno = jmeno;
            this.prijmeni = prijmeni;
            this.adresa = adresa;
            this.telefon = telefon;
            this.email = email;
        }
    }
}
