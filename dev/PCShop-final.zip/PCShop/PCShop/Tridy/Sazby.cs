﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PCShop
{
    public class Sazby
    {
        public int id { get; }
        public int sazba { get; }
        public string popis { get; }

        public Sazby(int id, int sazba, string popis)
        {
            this.id = id;
            this.sazba = sazba;
            this.popis = popis;
        }
    }
}