﻿namespace PCShop
{
    partial class KartaObjednavky
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblNazevZbozi = new System.Windows.Forms.Label();
            this.lblPocetKusu = new System.Windows.Forms.Label();
            this.lblDatumObjednani = new System.Windows.Forms.Label();
            this.lblOdkudObjednano = new System.Windows.Forms.Label();
            this.lblStatusObjednavky = new System.Windows.Forms.Label();
            this.dtpDatumObjednani = new System.Windows.Forms.DateTimePicker();
            this.cbOdkudObjednano = new System.Windows.Forms.ComboBox();
            this.lblNadpis = new System.Windows.Forms.Label();
            this.lblExpeduje = new System.Windows.Forms.Label();
            this.cbExpeduje = new System.Windows.Forms.ComboBox();
            this.cbZakaznik = new System.Windows.Forms.ComboBox();
            this.lblZakaznik = new System.Windows.Forms.Label();
            this.lblSazbaDph = new System.Windows.Forms.Label();
            this.cbSazbaDph = new System.Windows.Forms.ComboBox();
            this.lblCenaBezDph = new System.Windows.Forms.Label();
            this.lblCenaCelkemBezDph = new System.Windows.Forms.Label();
            this.lblCenaSDph = new System.Windows.Forms.Label();
            this.lblCenaCelkemSDph = new System.Windows.Forms.Label();
            this.btUzavritObjednavku = new System.Windows.Forms.Button();
            this.btVygenerovatFav = new System.Windows.Forms.Button();
            this.btPridatUpravit = new System.Windows.Forms.Button();
            this.btSmazat = new System.Windows.Forms.Button();
            this.cbPridatZbozi = new System.Windows.Forms.ComboBox();
            this.nudPocetKusu = new System.Windows.Forms.NumericUpDown();
            ((System.ComponentModel.ISupportInitialize)(this.nudPocetKusu)).BeginInit();
            this.SuspendLayout();
            // 
            // lblNazevZbozi
            // 
            this.lblNazevZbozi.AutoSize = true;
            this.lblNazevZbozi.Location = new System.Drawing.Point(12, 45);
            this.lblNazevZbozi.Name = "lblNazevZbozi";
            this.lblNazevZbozi.Size = new System.Drawing.Size(70, 13);
            this.lblNazevZbozi.TabIndex = 0;
            this.lblNazevZbozi.Text = "Název zboží:";
            // 
            // lblPocetKusu
            // 
            this.lblPocetKusu.AutoSize = true;
            this.lblPocetKusu.Location = new System.Drawing.Point(12, 73);
            this.lblPocetKusu.Name = "lblPocetKusu";
            this.lblPocetKusu.Size = new System.Drawing.Size(64, 13);
            this.lblPocetKusu.TabIndex = 1;
            this.lblPocetKusu.Text = "Počet kusů:";
            // 
            // lblDatumObjednani
            // 
            this.lblDatumObjednani.AutoSize = true;
            this.lblDatumObjednani.Location = new System.Drawing.Point(12, 102);
            this.lblDatumObjednani.Name = "lblDatumObjednani";
            this.lblDatumObjednani.Size = new System.Drawing.Size(92, 13);
            this.lblDatumObjednani.TabIndex = 2;
            this.lblDatumObjednani.Text = "Datum objednání:";
            // 
            // lblOdkudObjednano
            // 
            this.lblOdkudObjednano.AutoSize = true;
            this.lblOdkudObjednano.Location = new System.Drawing.Point(12, 129);
            this.lblOdkudObjednano.Name = "lblOdkudObjednano";
            this.lblOdkudObjednano.Size = new System.Drawing.Size(95, 13);
            this.lblOdkudObjednano.TabIndex = 3;
            this.lblOdkudObjednano.Text = "Odkud objednáno:";
            // 
            // lblStatusObjednavky
            // 
            this.lblStatusObjednavky.AutoSize = true;
            this.lblStatusObjednavky.Location = new System.Drawing.Point(12, 314);
            this.lblStatusObjednavky.Name = "lblStatusObjednavky";
            this.lblStatusObjednavky.Size = new System.Drawing.Size(98, 13);
            this.lblStatusObjednavky.TabIndex = 4;
            this.lblStatusObjednavky.Text = "Status objednávky:";
            // 
            // dtpDatumObjednani
            // 
            this.dtpDatumObjednani.Location = new System.Drawing.Point(119, 98);
            this.dtpDatumObjednani.MaxDate = new System.DateTime(2016, 12, 17, 0, 0, 0, 0);
            this.dtpDatumObjednani.MinDate = new System.DateTime(2016, 1, 1, 0, 0, 0, 0);
            this.dtpDatumObjednani.Name = "dtpDatumObjednani";
            this.dtpDatumObjednani.Size = new System.Drawing.Size(123, 20);
            this.dtpDatumObjednani.TabIndex = 10;
            this.dtpDatumObjednani.Value = new System.DateTime(2016, 12, 17, 0, 0, 0, 0);
            // 
            // cbOdkudObjednano
            // 
            this.cbOdkudObjednano.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbOdkudObjednano.FormattingEnabled = true;
            this.cbOdkudObjednano.Location = new System.Drawing.Point(119, 126);
            this.cbOdkudObjednano.Name = "cbOdkudObjednano";
            this.cbOdkudObjednano.Size = new System.Drawing.Size(123, 21);
            this.cbOdkudObjednano.TabIndex = 11;
            // 
            // lblNadpis
            // 
            this.lblNadpis.AutoSize = true;
            this.lblNadpis.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.lblNadpis.Location = new System.Drawing.Point(12, 9);
            this.lblNadpis.Name = "lblNadpis";
            this.lblNadpis.Size = new System.Drawing.Size(57, 20);
            this.lblNadpis.TabIndex = 12;
            this.lblNadpis.Text = "xxxxxx";
            // 
            // lblExpeduje
            // 
            this.lblExpeduje.AutoSize = true;
            this.lblExpeduje.Location = new System.Drawing.Point(12, 159);
            this.lblExpeduje.Name = "lblExpeduje";
            this.lblExpeduje.Size = new System.Drawing.Size(86, 13);
            this.lblExpeduje.TabIndex = 13;
            this.lblExpeduje.Text = "Obj. vyexpeduje:";
            // 
            // cbExpeduje
            // 
            this.cbExpeduje.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbExpeduje.FormattingEnabled = true;
            this.cbExpeduje.Location = new System.Drawing.Point(119, 156);
            this.cbExpeduje.Name = "cbExpeduje";
            this.cbExpeduje.Size = new System.Drawing.Size(123, 21);
            this.cbExpeduje.TabIndex = 14;
            // 
            // cbZakaznik
            // 
            this.cbZakaznik.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbZakaznik.FormattingEnabled = true;
            this.cbZakaznik.Location = new System.Drawing.Point(119, 186);
            this.cbZakaznik.Name = "cbZakaznik";
            this.cbZakaznik.Size = new System.Drawing.Size(123, 21);
            this.cbZakaznik.TabIndex = 15;
            // 
            // lblZakaznik
            // 
            this.lblZakaznik.AutoSize = true;
            this.lblZakaznik.Location = new System.Drawing.Point(12, 189);
            this.lblZakaznik.Name = "lblZakaznik";
            this.lblZakaznik.Size = new System.Drawing.Size(56, 13);
            this.lblZakaznik.TabIndex = 16;
            this.lblZakaznik.Text = "Zákazník:";
            // 
            // lblSazbaDph
            // 
            this.lblSazbaDph.AutoSize = true;
            this.lblSazbaDph.Location = new System.Drawing.Point(13, 222);
            this.lblSazbaDph.Name = "lblSazbaDph";
            this.lblSazbaDph.Size = new System.Drawing.Size(66, 13);
            this.lblSazbaDph.TabIndex = 17;
            this.lblSazbaDph.Text = "Sazba DPH:";
            // 
            // cbSazbaDph
            // 
            this.cbSazbaDph.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbSazbaDph.FormattingEnabled = true;
            this.cbSazbaDph.Location = new System.Drawing.Point(119, 219);
            this.cbSazbaDph.Name = "cbSazbaDph";
            this.cbSazbaDph.Size = new System.Drawing.Size(123, 21);
            this.cbSazbaDph.TabIndex = 18;
            this.cbSazbaDph.SelectedIndexChanged += new System.EventHandler(this.cbSazbaDph_SelectedIndexChanged);
            // 
            // lblCenaBezDph
            // 
            this.lblCenaBezDph.AutoSize = true;
            this.lblCenaBezDph.Location = new System.Drawing.Point(12, 262);
            this.lblCenaBezDph.Name = "lblCenaBezDph";
            this.lblCenaBezDph.Size = new System.Drawing.Size(118, 13);
            this.lblCenaBezDph.TabIndex = 19;
            this.lblCenaBezDph.Text = "Cena celkem bez DPH:";
            // 
            // lblCenaCelkemBezDph
            // 
            this.lblCenaCelkemBezDph.AutoSize = true;
            this.lblCenaCelkemBezDph.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.lblCenaCelkemBezDph.Location = new System.Drawing.Point(137, 258);
            this.lblCenaCelkemBezDph.Name = "lblCenaCelkemBezDph";
            this.lblCenaCelkemBezDph.Size = new System.Drawing.Size(57, 18);
            this.lblCenaCelkemBezDph.TabIndex = 20;
            this.lblCenaCelkemBezDph.Text = "xxxxxxx";
            // 
            // lblCenaSDph
            // 
            this.lblCenaSDph.AutoSize = true;
            this.lblCenaSDph.Location = new System.Drawing.Point(12, 284);
            this.lblCenaSDph.Name = "lblCenaSDph";
            this.lblCenaSDph.Size = new System.Drawing.Size(106, 13);
            this.lblCenaSDph.TabIndex = 21;
            this.lblCenaSDph.Text = "Cena celkem s DPH:";
            // 
            // lblCenaCelkemSDph
            // 
            this.lblCenaCelkemSDph.AutoSize = true;
            this.lblCenaCelkemSDph.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.lblCenaCelkemSDph.Location = new System.Drawing.Point(137, 280);
            this.lblCenaCelkemSDph.Name = "lblCenaCelkemSDph";
            this.lblCenaCelkemSDph.Size = new System.Drawing.Size(64, 18);
            this.lblCenaCelkemSDph.TabIndex = 22;
            this.lblCenaCelkemSDph.Text = "xxxxxxx";
            // 
            // btUzavritObjednavku
            // 
            this.btUzavritObjednavku.Location = new System.Drawing.Point(12, 340);
            this.btUzavritObjednavku.Name = "btUzavritObjednavku";
            this.btUzavritObjednavku.Size = new System.Drawing.Size(118, 23);
            this.btUzavritObjednavku.TabIndex = 23;
            this.btUzavritObjednavku.Text = "Uzavřít objednávku";
            this.btUzavritObjednavku.UseVisualStyleBackColor = true;
            this.btUzavritObjednavku.Click += new System.EventHandler(this.btUzavritObjednavku_Click);
            // 
            // btVygenerovatFav
            // 
            this.btVygenerovatFav.Location = new System.Drawing.Point(12, 369);
            this.btVygenerovatFav.Name = "btVygenerovatFav";
            this.btVygenerovatFav.Size = new System.Drawing.Size(118, 23);
            this.btVygenerovatFav.TabIndex = 24;
            this.btVygenerovatFav.Text = "Vygenerovat FAV";
            this.btVygenerovatFav.UseVisualStyleBackColor = true;
            this.btVygenerovatFav.Click += new System.EventHandler(this.btVygenerovatFav_Click);
            // 
            // btPridatUpravit
            // 
            this.btPridatUpravit.Location = new System.Drawing.Point(136, 340);
            this.btPridatUpravit.Name = "btPridatUpravit";
            this.btPridatUpravit.Size = new System.Drawing.Size(106, 23);
            this.btPridatUpravit.TabIndex = 25;
            this.btPridatUpravit.Text = "xxxxxxx";
            this.btPridatUpravit.UseVisualStyleBackColor = true;
            this.btPridatUpravit.Click += new System.EventHandler(this.btPridatUpravit_Click);
            // 
            // btSmazat
            // 
            this.btSmazat.Location = new System.Drawing.Point(136, 369);
            this.btSmazat.Name = "btSmazat";
            this.btSmazat.Size = new System.Drawing.Size(106, 23);
            this.btSmazat.TabIndex = 26;
            this.btSmazat.Text = "Smazat";
            this.btSmazat.UseVisualStyleBackColor = true;
            this.btSmazat.Click += new System.EventHandler(this.btSmazat_Click);
            // 
            // cbPridatZbozi
            // 
            this.cbPridatZbozi.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbPridatZbozi.FormattingEnabled = true;
            this.cbPridatZbozi.Location = new System.Drawing.Point(119, 42);
            this.cbPridatZbozi.Name = "cbPridatZbozi";
            this.cbPridatZbozi.Size = new System.Drawing.Size(123, 21);
            this.cbPridatZbozi.TabIndex = 27;
            this.cbPridatZbozi.SelectedIndexChanged += new System.EventHandler(this.cbPridatZbozi_SelectedIndexChanged);
            // 
            // nudPocetKusu
            // 
            this.nudPocetKusu.Location = new System.Drawing.Point(119, 70);
            this.nudPocetKusu.Name = "nudPocetKusu";
            this.nudPocetKusu.Size = new System.Drawing.Size(123, 20);
            this.nudPocetKusu.TabIndex = 28;
            this.nudPocetKusu.ValueChanged += new System.EventHandler(this.nudPocetKusu_ValueChanged);
            // 
            // KartaObjednavky
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(273, 404);
            this.Controls.Add(this.nudPocetKusu);
            this.Controls.Add(this.cbPridatZbozi);
            this.Controls.Add(this.btSmazat);
            this.Controls.Add(this.btPridatUpravit);
            this.Controls.Add(this.btVygenerovatFav);
            this.Controls.Add(this.btUzavritObjednavku);
            this.Controls.Add(this.lblCenaCelkemSDph);
            this.Controls.Add(this.lblCenaSDph);
            this.Controls.Add(this.lblCenaCelkemBezDph);
            this.Controls.Add(this.lblCenaBezDph);
            this.Controls.Add(this.cbSazbaDph);
            this.Controls.Add(this.lblSazbaDph);
            this.Controls.Add(this.lblZakaznik);
            this.Controls.Add(this.cbZakaznik);
            this.Controls.Add(this.cbExpeduje);
            this.Controls.Add(this.lblExpeduje);
            this.Controls.Add(this.lblNadpis);
            this.Controls.Add(this.cbOdkudObjednano);
            this.Controls.Add(this.dtpDatumObjednani);
            this.Controls.Add(this.lblStatusObjednavky);
            this.Controls.Add(this.lblOdkudObjednano);
            this.Controls.Add(this.lblDatumObjednani);
            this.Controls.Add(this.lblPocetKusu);
            this.Controls.Add(this.lblNazevZbozi);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.MaximizeBox = false;
            this.Name = "KartaObjednavky";
            this.Text = "Karta objednávky";
            this.Load += new System.EventHandler(this.KartaObjednavky_Load);
            ((System.ComponentModel.ISupportInitialize)(this.nudPocetKusu)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblNazevZbozi;
        private System.Windows.Forms.Label lblPocetKusu;
        private System.Windows.Forms.Label lblDatumObjednani;
        private System.Windows.Forms.Label lblOdkudObjednano;
        private System.Windows.Forms.Label lblStatusObjednavky;
        private System.Windows.Forms.DateTimePicker dtpDatumObjednani;
        private System.Windows.Forms.ComboBox cbOdkudObjednano;
        private System.Windows.Forms.Label lblNadpis;
        private System.Windows.Forms.Label lblExpeduje;
        private System.Windows.Forms.ComboBox cbExpeduje;
        private System.Windows.Forms.ComboBox cbZakaznik;
        private System.Windows.Forms.Label lblZakaznik;
        private System.Windows.Forms.Label lblSazbaDph;
        private System.Windows.Forms.ComboBox cbSazbaDph;
        private System.Windows.Forms.Label lblCenaBezDph;
        private System.Windows.Forms.Label lblCenaCelkemBezDph;
        private System.Windows.Forms.Label lblCenaSDph;
        private System.Windows.Forms.Label lblCenaCelkemSDph;
        private System.Windows.Forms.Button btUzavritObjednavku;
        private System.Windows.Forms.Button btVygenerovatFav;
        private System.Windows.Forms.Button btPridatUpravit;
        private System.Windows.Forms.Button btSmazat;
        private System.Windows.Forms.ComboBox cbPridatZbozi;
        private System.Windows.Forms.NumericUpDown nudPocetKusu;
    }
}