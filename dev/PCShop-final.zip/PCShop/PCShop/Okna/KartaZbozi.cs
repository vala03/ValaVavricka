﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PCShop
{
    public partial class KartaZbozi : Form
    {
        private Databaze db = new Databaze();
        private List<Zbozi> zbozi = new List<Zbozi>();
        private int index = 0;
        public bool smazat = false;

        public KartaZbozi(List<Zbozi> seznamZbozi, int index) //defaultne pro upravy
        {
            this.zbozi = seznamZbozi;
            this.index = index;
            InitializeComponent();
        }

        public KartaZbozi() //novy zbozi
        {
            this.zbozi = null;
            InitializeComponent();
            btAktualizovat.Text = "Přidat nové zboží";
        }

        private void KartaZbozi_Load(object sender, EventArgs e)
        {
            if (this.zbozi != null)
            {
                lblNadpisZbozi.Text = this.zbozi[index]._nazevZbozi;
                tbNazev.Text = this.zbozi[index]._nazevZbozi;
                tbPocetSkladem.Text = this.zbozi[index]._pocetZboziSkladem.ToString();
                tbPopis.Text = this.zbozi[index]._popisZbozi;
                tbCenaBezDph.Text = this.zbozi[index]._cenaZboziBezDph.ToString();
            }
            else
            {
                btSmazat.Visible = false;
                lblNadpisZbozi.Text = "Přidání nového zboží";
            }
        }

        private void btAktualizovat_Click(object sender, EventArgs e)
        {
            int n;
            if (tbNazev.Text != "" &&
                tbPopis.Text != "" &&
                tbPocetSkladem.Text != "" &&
                int.TryParse(tbPocetSkladem.Text, out n) == true &&
                tbCenaBezDph.Text != "" &&
                int.TryParse(tbCenaBezDph.Text, out n) == true)
            {
                if((this.zbozi != null)?db.zboziUpdate(this.zbozi[this.index]._idZbozi, tbNazev.Text, tbPopis.Text,
                    Convert.ToInt32(tbCenaBezDph.Text), Convert.ToInt32(tbPocetSkladem.Text))
                    :db.zboziPridat(tbNazev.Text, tbPopis.Text, Convert.ToInt32(tbCenaBezDph.Text),
                    Convert.ToInt32(tbPocetSkladem.Text)))
                {
                    MessageBox.Show((this.zbozi != null)?"Aktualizace proběhla":"Přidání proběhlo" +" úspěšně.");
                    this.DialogResult = DialogResult.OK;
                }
            }
            else
            {
                MessageBox.Show("Všechna pole jsou povinná a ujistěte se, že data máte zadané správně!");
            }
        }

        private void btSmazat_Click(object sender, EventArgs e)
        {
            if (db.kontrolaZboziVObjednavce(this.zbozi[this.index]._idZbozi))
            {
                if (db.zboziSmazat(this.zbozi[this.index]._idZbozi))
                {
                    MessageBox.Show("Zboží bylo úspěšně odstraněno z evidence.");
                    this.DialogResult = DialogResult.OK;
                    this.smazat = true;
                }
            }
            else
            {
                MessageBox.Show("Toto zboží je aktivní v evidenci objednávek."+Environment.NewLine+
                    "Vyřiďte nejprve všechny objednávky tohoto zboží.");
            }
        }
    }
}
