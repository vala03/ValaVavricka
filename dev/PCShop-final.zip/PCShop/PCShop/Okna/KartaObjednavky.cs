﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PCShop
{
    public partial class KartaObjednavky : Form
    {
        private Databaze db = new Databaze();
        private List<Zbozi> zbozi = new List<Zbozi>();
        private List<Objednavka> objednavka = new List<Objednavka>();
        private List<Zamestnanci> zamestnanci = new List<Zamestnanci>();
        private List<Zakaznici> zakaznici = new List<Zakaznici>();
        private List<Sazby> sazby = new List<Sazby>();

        private double cenaBezDphCelkem = 0;
        private int cbSazbaIndex = 0;
        private int index = 0;
        public bool smazat = false;

        public KartaObjednavky(List<Zbozi> zbozi)
        {
            this.zbozi = zbozi;
            db.dgvNaplnZamestnanci(out this.zamestnanci);
            db.dgvNaplnZakazniky(out this.zakaznici);
            db.dgvNaplnSazbami(out this.sazby);

            InitializeComponent();
            btPridatUpravit.Text = "Přidat";
            NaplnComboBoxy();
        }

        public KartaObjednavky(List<Objednavka> obj, List<Zbozi> zbozi, int index)
        {
            this.objednavka = obj;
            this.zbozi = zbozi;
            db.dgvNaplnZamestnanci(out this.zamestnanci);
            db.dgvNaplnZakazniky(out this.zakaznici);
            db.dgvNaplnSazbami(out this.sazby);

            this.index = index;
            InitializeComponent();
            btPridatUpravit.Text = "Upravit";
            NaplnComboBoxy();
        }

        private void NaplnComboBoxy()
        {
            int ii = 0;
            foreach (Zamestnanci i in zamestnanci)
            {
                cbExpeduje.Items.Add(i.jmeno + " " + i.prijmeni);
                if (btPridatUpravit.Text == "Upravit")
                    if (objednavka[index]._vyridil == i.id)
                        cbExpeduje.SelectedIndex = ii;
                ii++;
            }
            if (btPridatUpravit.Text == "Přidat")
                cbExpeduje.SelectedIndex = 0;

            ii = 0;
            foreach (Zakaznici i in zakaznici)
            {
                cbZakaznik.Items.Add(i.jmeno + " " + i.prijmeni);
                if (btPridatUpravit.Text == "Upravit")
                    if (objednavka[index]._idUzivatele == i.id)
                        cbZakaznik.SelectedIndex = ii;
                ii++;
            }
            if (btPridatUpravit.Text == "Přidat")
                cbZakaznik.SelectedIndex = 0;

            ii = 0;
            foreach (Zbozi i in zbozi)
            {
                cbPridatZbozi.Items.Add(i._nazevZbozi);
                if (btPridatUpravit.Text == "Upravit")
                    if (objednavka[index]._idZbozi == i._idZbozi)
                        cbPridatZbozi.SelectedIndex = ii;
                ii++;
            }
            if (btPridatUpravit.Text == "Přidat")
                cbPridatZbozi.SelectedIndex = 0;
            else
                cbPridatZbozi.Enabled = false;

            ii = 0;
            foreach (Sazby i in sazby)
            {
                cbSazbaDph.Items.Add(i.sazba + " %");
                if (btPridatUpravit.Text == "Upravit")
                    if (objednavka[index]._idSazbaDph == i.id)
                        cbSazbaDph.SelectedIndex = ii;
                ii++;
            }
            if (btPridatUpravit.Text == "Přidat")
                cbSazbaDph.SelectedIndex = 0;

            cbOdkudObjednano.Items.AddRange(new string[] { "E-Shop", "Kamenný obchod" });
            cbOdkudObjednano.SelectedIndex = 0;
        }

        private void KartaObjednavky_Load(object sender, EventArgs e)
        {
            dtpDatumObjednani.MaxDate = DateTime.Today;
            nudPocetKusu.Maximum = (from c in this.zbozi
                                    where c._idZbozi == ((btPridatUpravit.Text == "Upravit") ? objednavka[index]._idZbozi : zbozi[cbPridatZbozi.SelectedIndex]._idZbozi)
                                    select c._pocetZboziSkladem).First();

            if (btPridatUpravit.Text == "Upravit")
            {
                btSmazat.Enabled = true;
                btPridatUpravit.Enabled = (objednavka[index]._status == StatusObjednavky.Nezaplaceno) ? true : false;
                btUzavritObjednavku.Enabled = (objednavka[index]._status == StatusObjednavky.Nezaplaceno) ? true : false;
                btVygenerovatFav.Enabled = (objednavka[index]._status == StatusObjednavky.Nezaplaceno) ? true : false;
                nudPocetKusu.Enabled = (objednavka[index]._status == StatusObjednavky.Nezaplaceno) ? true : false;
                dtpDatumObjednani.Enabled = (objednavka[index]._status == StatusObjednavky.Nezaplaceno) ? true : false;
                cbExpeduje.Enabled = (objednavka[index]._status == StatusObjednavky.Nezaplaceno) ? true : false;
                cbOdkudObjednano.Enabled = (objednavka[index]._status == StatusObjednavky.Nezaplaceno) ? true : false;
                cbSazbaDph.Enabled = (objednavka[index]._status == StatusObjednavky.Nezaplaceno) ? true : false;
                cbZakaznik.Enabled = (objednavka[index]._status == StatusObjednavky.Nezaplaceno) ? true : false;

                try
                {
                    nudPocetKusu.Value = objednavka[index]._pocetKusu;
                }
                catch
                {
                    MessageBox.Show("Objednávku nelze spravovat, dokud nebude naskladněno požadované množství tohoto výrobku.");
                    this.DialogResult = DialogResult.OK;
                }

                dtpDatumObjednani.Value = objednavka[index]._datumObjednavky;
                cbOdkudObjednano.SelectedIndex = (objednavka[index]._odkudObjednano == OdkudObjednano.EShop) ? 0 : 1;
                lblNadpis.Text = "Objednávka č. " + objednavka[index]._id.ToString();
                lblStatusObjednavky.Text += (objednavka[index]._status == StatusObjednavky.Nezaplaceno) ? " nezaplaceno" : " zaplaceno";
            }
            else
            {
                btSmazat.Enabled = false;
                nudPocetKusu.Value = 1;
                dtpDatumObjednani.Value = DateTime.Today;
                this.Text = "Přidat objednávku";
                lblStatusObjednavky.Visible = false;
                btUzavritObjednavku.Enabled = false;
                btVygenerovatFav.Enabled = false;
                lblNadpis.Text = "Nová objednávka";
            }

            nudPocetKusu.Minimum = 1;
            PrepocetCen();
        }

        private void PrepocetCen()
        {
            this.cenaBezDphCelkem = (Convert.ToDouble((from c in this.zbozi
                                                       where c._idZbozi == ((btPridatUpravit.Text == "Upravit") ? objednavka[index]._idZbozi : zbozi[cbPridatZbozi.SelectedIndex]._idZbozi)
                                                       select c._cenaZboziBezDph).First()) *
                                        ((Convert.ToInt32(nudPocetKusu.Value))));
            lblCenaCelkemBezDph.Text = cenaBezDphCelkem.ToString() + " Kč";

            lblCenaCelkemSDph.Text = ((Convert.ToDouble((from c in this.zbozi
                                                        where c._idZbozi == ((btPridatUpravit.Text == "Upravit") ? objednavka[index]._idZbozi : zbozi[cbPridatZbozi.SelectedIndex]._idZbozi)
                                                        select c._cenaZboziBezDph).First()) * (Convert.ToInt32(nudPocetKusu.Value))) 
                                                        +
                                      (Convert.ToDouble((from c in this.zbozi
                                                        where c._idZbozi == ((btPridatUpravit.Text == "Upravit") ? objednavka[index]._idZbozi : zbozi[cbPridatZbozi.SelectedIndex]._idZbozi)
                                                        select c._cenaZboziBezDph).First()) * (Convert.ToInt32(nudPocetKusu.Value))) *
                                      (Convert.ToDouble(sazby[this.cbSazbaIndex].sazba) / 100)).ToString() + " Kč";
        }

        private void btPridatUpravit_Click(object sender, EventArgs e)
        {
            if ((btPridatUpravit.Text == "Upravit") ? db.objednavkaUpravit(this.objednavka[this.index]._id, this.objednavka[index]._idZbozi,
                    Convert.ToInt32(nudPocetKusu.Value), dtpDatumObjednani.Value,
                    (cbOdkudObjednano.SelectedIndex == 0) ? OdkudObjednano.EShop : OdkudObjednano.KamennaPobocka,
                    zamestnanci[cbExpeduje.SelectedIndex].id, zakaznici[cbZakaznik.SelectedIndex].id,
                    sazby[cbSazbaDph.SelectedIndex].id) :
                    db.objednavkaPridat(zbozi[cbPridatZbozi.SelectedIndex]._idZbozi, Convert.ToInt32(nudPocetKusu.Value), dtpDatumObjednani.Value,
                    (cbOdkudObjednano.SelectedIndex == 0) ? OdkudObjednano.EShop : OdkudObjednano.KamennaPobocka, StatusObjednavky.Nezaplaceno,
                    zamestnanci[cbExpeduje.SelectedIndex].id, zakaznici[cbZakaznik.SelectedIndex].id,
                    sazby[cbSazbaDph.SelectedIndex].id)
               )
            {
                MessageBox.Show(((btPridatUpravit.Text == "Upravit") ? "Aktualizace proběhla" : "Přidání proběhlo") + " úspěšně.");
                this.DialogResult = DialogResult.OK;
            }
            else
            {
                MessageBox.Show("Všechna pole jsou povinná a ujistěte se, že data máte zadané správně!");
            }
        }

        private void cbPridatZbozi_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (btPridatUpravit.Text == "Přidat")
                btPridatUpravit.Enabled = true;

            nudPocetKusu.Maximum = (from c in this.zbozi
                                    where c._idZbozi == ((btPridatUpravit.Text == "Upravit") ? objednavka[index]._idZbozi : zbozi[cbPridatZbozi.SelectedIndex]._idZbozi)
                                    select c._pocetZboziSkladem).First();
            try
            {
                nudPocetKusu.Value = 1;
            }
            catch
            {
                nudPocetKusu.Minimum = 0;
                nudPocetKusu.Value = 0;
                btPridatUpravit.Enabled = false;
            }
            PrepocetCen();
        }

        private void nudPocetKusu_ValueChanged(object sender, EventArgs e)
        {
            PrepocetCen();
        }

        private void cbSazbaDph_SelectedIndexChanged(object sender, EventArgs e)
        {
            this.cbSazbaIndex = cbSazbaDph.SelectedIndex;
            PrepocetCen();
        }

        private void btSmazat_Click(object sender, EventArgs e)
        {
            if (db.objednavkaSmazat(objednavka[index]._id))
            {
                MessageBox.Show("Objednávka byla úspěšně odstraněna z evidence.");
                this.DialogResult = DialogResult.OK;
                this.smazat = true;
            }
        }

        private void btUzavritObjednavku_Click(object sender, EventArgs e)
        {
            if (db.objednavkaUzavrit(objednavka[index]._id, StatusObjednavky.Zaplaceno) &&
                db.snizitPocetNaSklade(objednavka[index]._idZbozi, objednavka[index]._pocetKusu))
            {
                MessageBox.Show("Objednávka byla úspěšně zaplacena a uzavřena.");
                this.DialogResult = DialogResult.OK;
            }
            else
            {
                MessageBox.Show("Tuto objednávku nelze vyexpedovat a uzavřít, protože na skladě není dostatek kusů.");
            }
        }

        private void btVygenerovatFav_Click(object sender, EventArgs e)
        {
            Export exp = new Export();
            exp.ExportDoPDF(objednavka[index]._id, ((from c in this.zbozi where c._idZbozi == objednavka[index]._idZbozi select c._nazevZbozi).First()),
                this.cenaBezDphCelkem, ((from c in this.sazby where c.id == objednavka[index]._idSazbaDph select c.sazba).First()), objednavka[index]._pocetKusu,
                objednavka[index]._datumObjednavky, ((from c in this.zamestnanci where c.id == objednavka[index]._vyridil select c.jmeno).First()) + " " +
                ((from c in this.zamestnanci where c.id == objednavka[index]._vyridil select c.prijmeni).First()), ((from c in this.zakaznici where c.id == objednavka[index]._idUzivatele select c.jmeno).First()),
                ((from c in this.zakaznici where c.id == objednavka[index]._idUzivatele select c.prijmeni).First()), ((from c in this.zakaznici where c.id == objednavka[index]._idUzivatele select c.adresa).First()),
                ((from c in this.zakaznici where c.id == objednavka[index]._idUzivatele select c.telefon).First()), ((from c in this.zakaznici where c.id == objednavka[index]._idUzivatele select c.email).First()));
            MessageBox.Show("Faktura byla úspěšně vygenerována.");
        }
    }
}