﻿namespace PCShop
{
    partial class KartaZbozi
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblNazev = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.lblPocetSkladem = new System.Windows.Forms.Label();
            this.lblCenaBezDph = new System.Windows.Forms.Label();
            this.tbNazev = new System.Windows.Forms.TextBox();
            this.tbPopis = new System.Windows.Forms.TextBox();
            this.tbPocetSkladem = new System.Windows.Forms.TextBox();
            this.tbCenaBezDph = new System.Windows.Forms.TextBox();
            this.btAktualizovat = new System.Windows.Forms.Button();
            this.lblNadpisZbozi = new System.Windows.Forms.Label();
            this.btSmazat = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblNazev
            // 
            this.lblNazev.AutoSize = true;
            this.lblNazev.Location = new System.Drawing.Point(21, 50);
            this.lblNazev.Name = "lblNazev";
            this.lblNazev.Size = new System.Drawing.Size(41, 13);
            this.lblNazev.TabIndex = 0;
            this.lblNazev.Text = "Název:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(21, 76);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(36, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Popis:";
            // 
            // lblPocetSkladem
            // 
            this.lblPocetSkladem.AutoSize = true;
            this.lblPocetSkladem.Location = new System.Drawing.Point(21, 102);
            this.lblPocetSkladem.Name = "lblPocetSkladem";
            this.lblPocetSkladem.Size = new System.Drawing.Size(80, 13);
            this.lblPocetSkladem.TabIndex = 2;
            this.lblPocetSkladem.Text = "Počet skladem:";
            // 
            // lblCenaBezDph
            // 
            this.lblCenaBezDph.AutoSize = true;
            this.lblCenaBezDph.Location = new System.Drawing.Point(21, 128);
            this.lblCenaBezDph.Name = "lblCenaBezDph";
            this.lblCenaBezDph.Size = new System.Drawing.Size(81, 13);
            this.lblCenaBezDph.TabIndex = 3;
            this.lblCenaBezDph.Text = "Cena bez DPH:";
            // 
            // tbNazev
            // 
            this.tbNazev.Location = new System.Drawing.Point(121, 47);
            this.tbNazev.Name = "tbNazev";
            this.tbNazev.Size = new System.Drawing.Size(122, 20);
            this.tbNazev.TabIndex = 4;
            // 
            // tbPopis
            // 
            this.tbPopis.Location = new System.Drawing.Point(121, 73);
            this.tbPopis.Name = "tbPopis";
            this.tbPopis.Size = new System.Drawing.Size(122, 20);
            this.tbPopis.TabIndex = 5;
            // 
            // tbPocetSkladem
            // 
            this.tbPocetSkladem.Location = new System.Drawing.Point(121, 99);
            this.tbPocetSkladem.Name = "tbPocetSkladem";
            this.tbPocetSkladem.Size = new System.Drawing.Size(122, 20);
            this.tbPocetSkladem.TabIndex = 6;
            // 
            // tbCenaBezDph
            // 
            this.tbCenaBezDph.Location = new System.Drawing.Point(121, 125);
            this.tbCenaBezDph.Name = "tbCenaBezDph";
            this.tbCenaBezDph.Size = new System.Drawing.Size(122, 20);
            this.tbCenaBezDph.TabIndex = 7;
            // 
            // btAktualizovat
            // 
            this.btAktualizovat.Location = new System.Drawing.Point(121, 151);
            this.btAktualizovat.Name = "btAktualizovat";
            this.btAktualizovat.Size = new System.Drawing.Size(122, 23);
            this.btAktualizovat.TabIndex = 8;
            this.btAktualizovat.Text = "Aktualizovat";
            this.btAktualizovat.UseVisualStyleBackColor = true;
            this.btAktualizovat.Click += new System.EventHandler(this.btAktualizovat_Click);
            // 
            // lblNadpisZbozi
            // 
            this.lblNadpisZbozi.AutoSize = true;
            this.lblNadpisZbozi.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.lblNadpisZbozi.Location = new System.Drawing.Point(13, 13);
            this.lblNadpisZbozi.Name = "lblNadpisZbozi";
            this.lblNadpisZbozi.Size = new System.Drawing.Size(113, 16);
            this.lblNadpisZbozi.TabIndex = 9;
            this.lblNadpisZbozi.Text = "lblNadpisZbozi";
            // 
            // btSmazat
            // 
            this.btSmazat.Location = new System.Drawing.Point(16, 151);
            this.btSmazat.Name = "btSmazat";
            this.btSmazat.Size = new System.Drawing.Size(91, 23);
            this.btSmazat.TabIndex = 10;
            this.btSmazat.Text = "Smazat";
            this.btSmazat.UseVisualStyleBackColor = true;
            this.btSmazat.Click += new System.EventHandler(this.btSmazat_Click);
            // 
            // KartaZbozi
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(280, 190);
            this.Controls.Add(this.btSmazat);
            this.Controls.Add(this.lblNadpisZbozi);
            this.Controls.Add(this.btAktualizovat);
            this.Controls.Add(this.tbCenaBezDph);
            this.Controls.Add(this.tbPocetSkladem);
            this.Controls.Add(this.tbPopis);
            this.Controls.Add(this.tbNazev);
            this.Controls.Add(this.lblCenaBezDph);
            this.Controls.Add(this.lblPocetSkladem);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.lblNazev);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.MaximizeBox = false;
            this.Name = "KartaZbozi";
            this.Text = "Karta zboží";
            this.Load += new System.EventHandler(this.KartaZbozi_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblNazev;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label lblPocetSkladem;
        private System.Windows.Forms.Label lblCenaBezDph;
        private System.Windows.Forms.TextBox tbNazev;
        private System.Windows.Forms.TextBox tbPopis;
        private System.Windows.Forms.TextBox tbPocetSkladem;
        private System.Windows.Forms.TextBox tbCenaBezDph;
        private System.Windows.Forms.Button btAktualizovat;
        private System.Windows.Forms.Label lblNadpisZbozi;
        private System.Windows.Forms.Button btSmazat;
    }
}