﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PCShop
{
    public partial class HlavniFormular : Form
    {
        private List<Zbozi> seznamZbozi = new List<Zbozi>();
        private List<Objednavka> seznamObjednavek = new List<Objednavka>();
        private Databaze db = new Databaze();
        private int IdLogin;
        private int Opravneni;

        public HlavniFormular()
        {
            PrihlaseniDialog();
            InitializeComponent();
        }

        private void PrihlaseniDialog()
        {
            PrihlasovaciFormular pf = new PrihlasovaciFormular();
            pf.StartPosition = FormStartPosition.CenterScreen;
            DialogResult r = pf.ShowDialog();
            if (r == DialogResult.OK)
            {
                this.IdLogin = pf.IdLogin;
            }
            else
                Environment.Exit(0);
            return;
        }

        private void ukončitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            this.Icon = Properties.Resources.logo;
            this.Opravneni = db.ZjistiOpravneniUzivatele(this.IdLogin);
            dgvNaplnit(this.Opravneni);

            lblPrihlasenyUzivatelHodnota.Text = db.zjistitJmenoPrihlaseneho(this.IdLogin);
            lblPoziceHodnota.Text = db.zjistitPoziciPrihlaseneho(this.Opravneni);
        }

        private void dgvNaplnit(int opravneni, bool volbaDat = true)
        {
            dgvDataOblast.Rows.Clear();
            dgvDataOblast.Columns.Clear();
            db.dgvNaplnZbozim(out this.seznamZbozi);

            if ((opravneni == 1) || ((opravneni == 3) && (volbaDat == true))) //pro zboží
            {
                dgvDataOblast.Columns.Add("nazevZboziColumn", "Název zboží");
                dgvDataOblast.Columns.Add("popisZboziColumn", "Popis zboží");
                dgvDataOblast.Columns.Add("cenaBezDphColumn", "Cena bez DPH");
                dgvDataOblast.Columns.Add("pocetSklademColumn", "Počet skladem");
                foreach (var i in this.seznamZbozi)
                    dgvDataOblast.Rows.Add(i._nazevZbozi, i._popisZbozi, i._cenaZboziBezDph,
                        i._pocetZboziSkladem);
            }
            else if ((opravneni == 2) || ((opravneni == 3) && (volbaDat == false))) //pro objednávky
            {
                dgvDataOblast.Columns.Add("nazevZboziColumn", "Název zboží");
                dgvDataOblast.Columns.Add("pocetKusuColumn", "Počet kusů");
                dgvDataOblast.Columns.Add("datumObjednavkyColumn", "Datum objednávky");
                dgvDataOblast.Columns.Add("mistoObjednaniColumn", "Místo objednání");
                db.dgvNaplnObjednavkami(out this.seznamObjednavek);
                foreach (var i in this.seznamObjednavek)
                    dgvDataOblast.Rows.Add((from c in this.seznamZbozi where c._idZbozi == i._idZbozi select c._nazevZbozi).First(),
                        i._pocetKusu, i._datumObjednavky, (i._odkudObjednano == OdkudObjednano.EShop) ? "E-Shop" : "Kamenná pobočka");
            }
        }

        private void dgvDataOblast_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            MessageBox.Show(dgvDataOblast.Rows[e.RowIndex].Cells[e.ColumnIndex].Value.ToString());
        }
    }
}
