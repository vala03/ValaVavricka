﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Security.Cryptography;
using System.Reflection;
using System.IO;
using System.Data.SqlClient;

namespace PCShop
{
    class Databaze
    {
        private SqlConnection dbPripojeni;
        private SqlCommand dbPrikaz;
        private SqlDataReader reader;
        private string ConnectionString;

        public Databaze()
        {
            string exec = Assembly.GetExecutingAssembly().Location;
            string cesta = (Path.GetDirectoryName(exec));
            AppDomain.CurrentDomain.SetData("DataDirectory", cesta);
            ConnectionString = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=|DataDirectory|\databaze.mdf;Integrated Security=True;Connect Timeout=30";
            dbPripojeni = new SqlConnection(ConnectionString);
            dbPripojeni.Open();
        }

        public bool zavritDB
        {
            get
            {
                try
                {
                    dbPripojeni.Close();
                    return true;
                }
                catch
                {
                    return false;
                }
            }
        }

        public int ZkontrolujPrihlaseni(string login, string heslo) //vystupy: id uzivatele=udaje ok, -1=spatne udaje
        {
            string passwd = md5_encrypt(heslo);
            dbPrikaz = new SqlCommand("SELECT COUNT(*) FROM app_login WHERE login=@Login AND password=@Passwd", dbPripojeni);
            dbPrikaz.Parameters.Add("@Login", System.Data.SqlDbType.NVarChar).Value = login;
            dbPrikaz.Parameters.Add("@Passwd", System.Data.SqlDbType.NVarChar).Value = passwd;
            if((int)dbPrikaz.ExecuteScalar() == 1)
            {
                dbPrikaz = new SqlCommand("SELECT id FROM app_login WHERE login=@Login AND password=@Passwd", dbPripojeni);
                dbPrikaz.Parameters.Add("@Login", System.Data.SqlDbType.NVarChar).Value = login;
                dbPrikaz.Parameters.Add("@Passwd", System.Data.SqlDbType.NVarChar).Value = passwd;
                return (int)dbPrikaz.ExecuteScalar();
            }
            else
                return -1;
        }

        /* private string md5_decrypt(string text)
         {
             if ((text == null) || (text.Length == 0))
                 return string.Empty;

             //Calculate MD5 hash. This requires that the string is splitted into a byte[].
             MD5 md5 = new MD5CryptoServiceProvider();
             byte[] textToHash = Encoding.Default.GetBytes(text);
             byte[] vysledek = md5.ComputeHash(textToHash);

             //konverze bitoveho pole zpatky na string
             return BitConverter.ToString(vysledek);
         }*/

        private string md5_encrypt(string text)
        {
            MD5 md5Hash = MD5.Create();
            byte[] data = md5Hash.ComputeHash(Encoding.UTF8.GetBytes(text));
            StringBuilder sBuilder = new StringBuilder();
            for (int i = 0; i < data.Length; i++)
            {
                sBuilder.Append(data[i].ToString("x2"));
            }
            return sBuilder.ToString();
        }

        public int ZjistiOpravneniUzivatele(int idUzivatel)
        {
            dbPrikaz = new SqlCommand("SELECT pozice FROM zamestnanci WHERE login=@Login", dbPripojeni);
            dbPrikaz.Parameters.Add("@Login", System.Data.SqlDbType.Int).Value = idUzivatel;
            return (int)dbPrikaz.ExecuteScalar();
        }

        public void dgvNaplnZbozim(out List<Zbozi> zbozi)
        {
            zbozi = new List<Zbozi>();
            dbPrikaz = new SqlCommand("SELECT * FROM Zbozi", dbPripojeni);
            reader = dbPrikaz.ExecuteReader();
            while (reader.Read())
            {
                zbozi.Add(new Zbozi(Convert.ToInt32(reader["id"]), reader["nazev"].ToString(),
                reader["popis"].ToString(), Convert.ToInt32(reader["cena_bez_dph"]),
                Convert.ToInt32(reader["pocet_skladem"])));
            }
            reader.Close();
        }

        public void dgvNaplnObjednavkami(out List<Objednavka> objednavky)
        {
            objednavky = new List<Objednavka>();
            dbPrikaz = new SqlCommand("SELECT * FROM objednavka", dbPripojeni);
            reader = dbPrikaz.ExecuteReader();
            while (reader.Read())
            {
                objednavky.Add(new Objednavka(Convert.ToInt32(reader["id"]), Convert.ToInt32(reader["id_zbozi"]),
                    Convert.ToInt32(reader["pocet_kusu"]), Convert.ToDateTime(reader["datum_uskutecneni"]),
                    (Convert.ToInt32(reader["odkud_objednano"]) == 1) ? OdkudObjednano.EShop : OdkudObjednano.KamennaPobocka,
                    (Convert.ToInt32(reader["status"]) == 0) ? StatusObjednavky.Nezaplaceno : StatusObjednavky.Zaplaceno,
                    Convert.ToInt32(reader["vyridil"]), Convert.ToInt32(reader["id_uzivatel"]),
                    Convert.ToInt32(reader["sazba_dph"]), Convert.ToInt32(reader["cena_s_dph"])));
            }
            reader.Close();
        }

        public string zjistitJmenoPrihlaseneho(int id)
        {
            string jmeno = null;
            dbPrikaz = new SqlCommand("SELECT jmeno, prijmeni FROM zamestnanci WHERE login=@Login",
                dbPripojeni);
            dbPrikaz.Parameters.Add("@Login", System.Data.SqlDbType.Int).Value = id;
            reader = dbPrikaz.ExecuteReader();
            while (reader.Read())
            {
                jmeno = reader["jmeno"] + " " + reader["prijmeni"];
            }
            reader.Close();
            return jmeno;
        }

        public string zjistitPoziciPrihlaseneho(int opravneni)
        {
            dbPrikaz = new SqlCommand("SELECT nazev FROM pozice WHERE id=@IdOpravneni",
                dbPripojeni);
            dbPrikaz.Parameters.Add("@IdOpravneni", System.Data.SqlDbType.Int).Value = opravneni;
            return dbPrikaz.ExecuteScalar().ToString();
        }
    }
}