﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PCShop
{
    public enum OdkudObjednano { EShop, KamennaPobocka };
    public enum StatusObjednavky { Nezaplaceno, Zaplaceno };

    class Objednavka
    {
        private int id;
        private int idZbozi;
        private int pocetKusu;
        private DateTime datumObjednavky;
        private OdkudObjednano odkudObjednano;
        private StatusObjednavky status;
        private int vyridil;
        private int idUzivatele;
        private int idSazbaDph;
        private int cenaCelkem;

        public Objednavka(int id, int idzbozi, int pocetkusu, DateTime datum, OdkudObjednano odkud,
            StatusObjednavky status, int vyridil, int iduzivatele, int idsazbadph, int cenacelkem)
        {
            this.id = id;
            this.idZbozi = idzbozi;
            this.pocetKusu = pocetkusu;
            this.datumObjednavky = datum;
            this.odkudObjednano = odkud;
            this.status = status;
            this.vyridil = vyridil;
            this.idUzivatele = iduzivatele;
            this.idSazbaDph = idsazbadph;
            this.cenaCelkem = cenacelkem;
        }

        public int _id { get { return this.id; } }
        public int _idZbozi { get { return this.idZbozi; } }
        public int _pocetKusu { get { return this.pocetKusu; } }
        public DateTime _datumObjednavky { get { return this.datumObjednavky; } }
        public OdkudObjednano _odkudObjednano { get { return this.odkudObjednano; } }
        public StatusObjednavky _status { get { return this.status; } }
        public int _vyridil { get { return this.vyridil; } }
        public int _idUzivatele { get { return this.idUzivatele; } }
        public int _idSazbaDph { get { return this.idSazbaDph; } }
        public int _cenaCelkem { get { return this.cenaCelkem; } }
    }
}
