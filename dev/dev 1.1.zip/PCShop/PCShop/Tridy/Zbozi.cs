﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PCShop
{
    class Zbozi
    {
        private int idZbozi;
        private string nazevZbozi;
        private string popisZbozi;
        private int cenaZboziBezDph;
        private int pocetZboziSkladem;

        public Zbozi(int id, string nazev, string popis, int cenabezdph, int pocetskladem)
        {
            this.idZbozi = id;
            this.nazevZbozi = nazev;
            this.popisZbozi = popis;
            this.cenaZboziBezDph = cenabezdph;
            this.pocetZboziSkladem = pocetskladem;
        }

        public int _idZbozi { get { return this.idZbozi; } }
        public string _nazevZbozi { get { return this.nazevZbozi; } }
        public string _popisZbozi { get { return this.popisZbozi; } }
        public int _cenaZboziBezDph { get { return this.cenaZboziBezDph; } }
        public int _pocetZboziSkladem { get { return this.pocetZboziSkladem; } }
    }
}
