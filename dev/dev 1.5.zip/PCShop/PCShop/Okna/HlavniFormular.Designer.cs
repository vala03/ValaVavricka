﻿namespace PCShop
{
    partial class HlavniFormular
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.programToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ukončitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.dgvDataOblast = new System.Windows.Forms.DataGridView();
            this.Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.lblPrihlasenyUzivatel = new System.Windows.Forms.Label();
            this.lblPrihlasenyUzivatelHodnota = new System.Windows.Forms.Label();
            this.lblPozice = new System.Windows.Forms.Label();
            this.lblPoziceHodnota = new System.Windows.Forms.Label();
            this.novyXToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pohledToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.skladníkToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.účetníToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDataOblast)).BeginInit();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.programToolStripMenuItem,
            this.novyXToolStripMenuItem,
            this.pohledToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(753, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // programToolStripMenuItem
            // 
            this.programToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ukončitToolStripMenuItem});
            this.programToolStripMenuItem.Name = "programToolStripMenuItem";
            this.programToolStripMenuItem.Size = new System.Drawing.Size(65, 20);
            this.programToolStripMenuItem.Text = "Program";
            // 
            // ukončitToolStripMenuItem
            // 
            this.ukončitToolStripMenuItem.Name = "ukončitToolStripMenuItem";
            this.ukončitToolStripMenuItem.Size = new System.Drawing.Size(115, 22);
            this.ukončitToolStripMenuItem.Text = "Ukončit";
            this.ukončitToolStripMenuItem.Click += new System.EventHandler(this.ukončitToolStripMenuItem_Click);
            // 
            // dgvDataOblast
            // 
            this.dgvDataOblast.AllowUserToAddRows = false;
            this.dgvDataOblast.AllowUserToDeleteRows = false;
            this.dgvDataOblast.AllowUserToOrderColumns = true;
            this.dgvDataOblast.AllowUserToResizeRows = false;
            this.dgvDataOblast.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dgvDataOblast.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvDataOblast.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column1});
            this.dgvDataOblast.Location = new System.Drawing.Point(12, 27);
            this.dgvDataOblast.MultiSelect = false;
            this.dgvDataOblast.Name = "dgvDataOblast";
            this.dgvDataOblast.ReadOnly = true;
            this.dgvDataOblast.RowHeadersVisible = false;
            this.dgvDataOblast.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvDataOblast.Size = new System.Drawing.Size(551, 270);
            this.dgvDataOblast.TabIndex = 1;
            this.dgvDataOblast.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvDataOblast_CellClick);
            this.dgvDataOblast.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvDataOblast_CellDoubleClick);
            // 
            // Column1
            // 
            this.Column1.HeaderText = "Column1";
            this.Column1.Name = "Column1";
            this.Column1.ReadOnly = true;
            this.Column1.Width = 73;
            // 
            // lblPrihlasenyUzivatel
            // 
            this.lblPrihlasenyUzivatel.AutoSize = true;
            this.lblPrihlasenyUzivatel.Font = new System.Drawing.Font("Arial", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.lblPrihlasenyUzivatel.Location = new System.Drawing.Point(569, 31);
            this.lblPrihlasenyUzivatel.Name = "lblPrihlasenyUzivatel";
            this.lblPrihlasenyUzivatel.Size = new System.Drawing.Size(145, 16);
            this.lblPrihlasenyUzivatel.TabIndex = 2;
            this.lblPrihlasenyUzivatel.Text = "Přihlášený uživatel:";
            // 
            // lblPrihlasenyUzivatelHodnota
            // 
            this.lblPrihlasenyUzivatelHodnota.AutoSize = true;
            this.lblPrihlasenyUzivatelHodnota.Location = new System.Drawing.Point(572, 50);
            this.lblPrihlasenyUzivatelHodnota.Name = "lblPrihlasenyUzivatelHodnota";
            this.lblPrihlasenyUzivatelHodnota.Size = new System.Drawing.Size(35, 13);
            this.lblPrihlasenyUzivatelHodnota.TabIndex = 3;
            this.lblPrihlasenyUzivatelHodnota.Text = "label2";
            // 
            // lblPozice
            // 
            this.lblPozice.AutoSize = true;
            this.lblPozice.Font = new System.Drawing.Font("Arial", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.lblPozice.Location = new System.Drawing.Point(570, 80);
            this.lblPozice.Name = "lblPozice";
            this.lblPozice.Size = new System.Drawing.Size(58, 16);
            this.lblPozice.TabIndex = 4;
            this.lblPozice.Text = "Pozice:";
            // 
            // lblPoziceHodnota
            // 
            this.lblPoziceHodnota.AutoSize = true;
            this.lblPoziceHodnota.Location = new System.Drawing.Point(573, 98);
            this.lblPoziceHodnota.Name = "lblPoziceHodnota";
            this.lblPoziceHodnota.Size = new System.Drawing.Size(35, 13);
            this.lblPoziceHodnota.TabIndex = 5;
            this.lblPoziceHodnota.Text = "label2";
            // 
            // novyXToolStripMenuItem
            // 
            this.novyXToolStripMenuItem.Name = "novyXToolStripMenuItem";
            this.novyXToolStripMenuItem.Size = new System.Drawing.Size(86, 20);
            this.novyXToolStripMenuItem.Text = "Nové/á xxxxx";
            this.novyXToolStripMenuItem.Click += new System.EventHandler(this.novyXToolStripMenuItem_Click);
            // 
            // pohledToolStripMenuItem
            // 
            this.pohledToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.skladníkToolStripMenuItem,
            this.účetníToolStripMenuItem});
            this.pohledToolStripMenuItem.Name = "pohledToolStripMenuItem";
            this.pohledToolStripMenuItem.Size = new System.Drawing.Size(56, 20);
            this.pohledToolStripMenuItem.Text = "Pohled";
            this.pohledToolStripMenuItem.Visible = false;
            // 
            // skladníkToolStripMenuItem
            // 
            this.skladníkToolStripMenuItem.CheckOnClick = true;
            this.skladníkToolStripMenuItem.Name = "skladníkToolStripMenuItem";
            this.skladníkToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.skladníkToolStripMenuItem.Text = "Skladník";
            this.skladníkToolStripMenuItem.Click += new System.EventHandler(this.skladníkToolStripMenuItem_Click);
            // 
            // účetníToolStripMenuItem
            // 
            this.účetníToolStripMenuItem.CheckOnClick = true;
            this.účetníToolStripMenuItem.Name = "účetníToolStripMenuItem";
            this.účetníToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.účetníToolStripMenuItem.Text = "Účetní";
            this.účetníToolStripMenuItem.Click += new System.EventHandler(this.účetníToolStripMenuItem_Click);
            // 
            // HlavniFormular
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(753, 309);
            this.Controls.Add(this.lblPoziceHodnota);
            this.Controls.Add(this.lblPozice);
            this.Controls.Add(this.lblPrihlasenyUzivatelHodnota);
            this.Controls.Add(this.lblPrihlasenyUzivatel);
            this.Controls.Add(this.dgvDataOblast);
            this.Controls.Add(this.menuStrip1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.MainMenuStrip = this.menuStrip1;
            this.MaximizeBox = false;
            this.Name = "HlavniFormular";
            this.Text = "PC-Shop evidence";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDataOblast)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem programToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ukončitToolStripMenuItem;
        private System.Windows.Forms.DataGridView dgvDataOblast;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column1;
        private System.Windows.Forms.Label lblPrihlasenyUzivatel;
        private System.Windows.Forms.Label lblPrihlasenyUzivatelHodnota;
        private System.Windows.Forms.Label lblPozice;
        private System.Windows.Forms.Label lblPoziceHodnota;
        private System.Windows.Forms.ToolStripMenuItem novyXToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem pohledToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem skladníkToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem účetníToolStripMenuItem;
    }
}

