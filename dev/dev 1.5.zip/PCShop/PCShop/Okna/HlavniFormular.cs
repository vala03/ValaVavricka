﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PCShop
{
    public partial class HlavniFormular : Form
    {
        private List<Zbozi> seznamZbozi = new List<Zbozi>();
        private List<Objednavka> seznamObjednavek = new List<Objednavka>();
        private Databaze db = new Databaze();
        private int IdLogin;
        private int Opravneni;
        private int RowIndex = 0;

        public HlavniFormular()
        {
            PrihlaseniDialog();
            InitializeComponent();
        }

        private void PrihlaseniDialog()
        {
            PrihlasovaciFormular pf = new PrihlasovaciFormular();
            pf.StartPosition = FormStartPosition.CenterScreen;
            DialogResult r = pf.ShowDialog();
            if (r == DialogResult.OK)
            {
                this.IdLogin = pf.IdLogin;
            }
            else
                Environment.Exit(0);
            return;
        }

        private void ukončitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            this.Icon = Properties.Resources.logo;
            this.Opravneni = db.ZjistiOpravneniUzivatele(this.IdLogin);
            if (this.Opravneni == 3)
            {
                pohledToolStripMenuItem.Visible = true;
                skladníkToolStripMenuItem.Checked = true;
            }
            dgvNaplnit(this.Opravneni);

            lblPrihlasenyUzivatelHodnota.Text = db.zjistitJmenoPrihlaseneho(this.IdLogin);
            lblPoziceHodnota.Text = db.zjistitPoziciPrihlaseneho(this.Opravneni);
        }

        private void dgvNaplnit(int opravneni, bool volbaDat = true)
        {
            dgvDataOblast.Rows.Clear();
            dgvDataOblast.Columns.Clear();
            db.dgvNaplnZbozim(out this.seznamZbozi);

            if ((opravneni == 1) || ((opravneni == 3) && (volbaDat == true))) //pro zboží
            {
                novyXToolStripMenuItem.Text = "Nové zboží";
                dgvDataOblast.Columns.Add("nazevZboziColumn", "Název zboží");
                dgvDataOblast.Columns.Add("popisZboziColumn", "Popis zboží");
                dgvDataOblast.Columns.Add("cenaBezDphColumn", "Cena bez DPH");
                dgvDataOblast.Columns.Add("pocetSklademColumn", "Počet skladem");
                foreach (var i in this.seznamZbozi)
                    dgvDataOblast.Rows.Add(i._nazevZbozi, i._popisZbozi, i._cenaZboziBezDph + " Kč",
                        i._pocetZboziSkladem + " ks");
            }
            else if ((opravneni == 2) || ((opravneni == 3) && (volbaDat == false))) //pro objednávky
            {
                novyXToolStripMenuItem.Text = "Nová objednávka";
                dgvDataOblast.Columns.Add("nazevZboziColumn", "Název zboží");
                dgvDataOblast.Columns.Add("pocetKusuColumn", "Počet kusů");
                dgvDataOblast.Columns.Add("datumObjednavkyColumn", "Datum objednávky");
                dgvDataOblast.Columns.Add("mistoObjednaniColumn", "Místo objednání");
                db.dgvNaplnObjednavkami(out this.seznamObjednavek);
                foreach (var i in this.seznamObjednavek)
                    dgvDataOblast.Rows.Add((from c in this.seznamZbozi where c._idZbozi == i._idZbozi select c._nazevZbozi).First(),
                        i._pocetKusu + " ks", i._datumObjednavky, (i._odkudObjednano == OdkudObjednano.EShop) ? "E-Shop" : "Kamenná pobočka");
            }
            dgvDataOblast.Rows[this.RowIndex].Selected = true;
        }

        private void dgvDataOblast_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            this.RowIndex = e.RowIndex;
        }

        private void dgvDataOblast_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            //MessageBox.Show(dgvDataOblast.Rows[e.RowIndex].Cells[e.ColumnIndex].Value.ToString());
            
            KartaZbozi kz = new KartaZbozi(this.seznamZbozi, e.RowIndex);
            kz.StartPosition = FormStartPosition.CenterScreen;
            DialogResult r = kz.ShowDialog();
            if (r == DialogResult.OK || r == DialogResult.Cancel)
            {
                if (kz.smazat && (RowIndex > 0))
                    this.RowIndex--;
                dgvNaplnit(Opravneni); 
                kz.Close();
            }
            else
                
            return;
        }

        private void novyXToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (novyXToolStripMenuItem.Text == "Nové zboží")
            {
                KartaZbozi kz = new KartaZbozi();
                kz.StartPosition = FormStartPosition.CenterScreen;
                DialogResult r = kz.ShowDialog();
                if (r == DialogResult.OK || r == DialogResult.Cancel)
                {
                    dgvNaplnit(Opravneni);
                    kz.Close();
                }
            }
            else
            {
                
            }
        }

        private void skladníkToolStripMenuItem_Click(object sender, EventArgs e)
        {
            skladníkToolStripMenuItem.Checked = true;
            účetníToolStripMenuItem.Checked = false;
            dgvNaplnit(this.Opravneni, true);
        }

        private void účetníToolStripMenuItem_Click(object sender, EventArgs e)
        {
            skladníkToolStripMenuItem.Checked = false;
            účetníToolStripMenuItem.Checked = true;
            dgvNaplnit(this.Opravneni, false);
        }
    }
}
